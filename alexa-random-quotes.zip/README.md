# Alexa - Random Quotes

Alexa skill that returns random quotes.

## Build Zip

```bash
./package-lambda.sh
```

## Acknowledgements

* Alexa fact demo - [alexa/skill-sample-nodejs-fact](https://github.com/alexa/skill-sample-nodejs-fact)
* Quotes - [mubaris/motivate](https://github.com/mubaris/motivate)
