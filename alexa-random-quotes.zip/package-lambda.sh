rm alexa-random-quotes.zip
zip -r alexa-random-quotes.zip *
